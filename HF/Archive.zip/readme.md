Run project: 
npm install
npm run dev